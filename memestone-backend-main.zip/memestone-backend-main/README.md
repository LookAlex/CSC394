# Memestone Backend

Gratefully hijacked directly from one Jason Watmore:
https://github.com/cornflourblue/node-mysql-crud-api 